Hello in the Fox language, my name is Hossam, a developer of the Fox language. The language was created by an Iraqi person, but the problem is that the Fox programming language is based on Batch, so it cannot be run on any system other than Windows. Explanation of some language commands: Some commands will be based on PowerShell. 1. msgbox = msg * 2. msgbox-input = vbs and batch file 3. var = set %1=%2 and so on. The language was created by an Iraqi person. Objectives: 1. To learn what programming is; some young people, when learning, do not apply what they have learned, so the language provides this for free. 2. To learn the basics to have an idea about the fundamentals of programming. 3. The majority of the Iraqi people do not care about programming, so creating a programming language for computers is a great thing that attracts them to learn. Additional information: You will find an enormous number of files; the reason for this is that vocabulary needs to be defined for the computer, which leads to a large number of files. Some files have taken code from artificial intelligence. Due to the large number of commands, if we combine all the codes, the code will be very long. Don't forget to subscribe to my YouTube channel. Channel name: foxy13 tons






مرحبا في لغه بافوكس, انا اسمي حسام مطور لغه بافوكس تم انشاء اللغه من قبل شخص عراقي , لاكن المشكله ان لغه بافوكس البرمجيه مبنيه على باتش اي لا يمكن تشغيلها على اي نضام ماعدى وندوز windows

شرح بعض اوامر الغه :
ستكون بعض الاوامر مبنيه على الباور شل
1.msgbox = msg *
2.msgbox-input = vbs and batch file
3. var = set %1=%2
وهاكذا
تم انشاء اللغه من قبل شخص عراقي
الاهداف:
1.تعلم ماهي البرمجه بعض الشباب عند التعلم لايقومون بتطبيق ماتعلموه فللغه توفر هذا الشيء بشكل مجاني
2.تعلم الاساسيات لبناء فكره عن اساسيات البرمجه
3. الاغلبيه من الشعب العراقي لايهتم للبرمجه فصنع لغه برمجيه للحواسيب شيء عضيم
يجذبهم للتعلم

المعلومات الاضافيه:
ستجد كم هائل من الملفات يكون السبب هو ان يجب تعريف المفردات للكمبيوتر وهاذا يوئدي الى كثره الملفات

بعض الملفات تم اخذ اكواد من الذكاء الاصطناعي

بسبب كثره الاوامر
اذا جمعنا كل الاكواد
سيكون الكود طويل جدا


لاتنسى الاشتراك في قناتي على اليوتيوب
اسم القناة:
foxy13 tons